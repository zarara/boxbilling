# Embed and integrate parts of BoxBilling to your website

Module purpose is to give ability for users to include parts of BoxBilling
to other websites.