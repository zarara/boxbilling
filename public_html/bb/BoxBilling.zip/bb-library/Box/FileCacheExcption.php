<?php

class FileCacheException extends Exception{}